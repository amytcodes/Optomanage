import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { ClinicProvider } from './context/ClinicContext';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Patients } from './pages/Patients';
import { Prescriptions } from './pages/Prescriptions';
import { Orders } from './pages/Orders';
import { FollowUps } from './pages/FollowUps';

function App() {
  return (
    <BrowserRouter>
      <ClinicProvider>
        <Toaster position="top-center" richColors />
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="patients" element={<Patients />} />
            <Route path="prescriptions" element={<Prescriptions />} />
            <Route path="orders" element={<Orders />} />
            <Route path="follow-ups" element={<FollowUps />} />
          </Route>
        </Routes>
      </ClinicProvider>
    </BrowserRouter>
  );
}

export default App;

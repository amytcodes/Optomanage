import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { Patient, Prescription, Order } from '../lib/database.types';
import { toast } from 'sonner';

interface ClinicContextType {
  patients: Patient[];
  prescriptions: Prescription[];
  orders: Order[];
  loading: boolean;
  refreshData: () => Promise<void>;
  addPatient: (patient: Omit<Patient, 'id' | 'created_at' | 'updated_at'>) => Promise<Patient | null>;
  updatePatient: (id: string, updates: Partial<Patient>) => Promise<void>;
  deletePatient: (id: string) => Promise<void>;
  addPrescription: (prescription: Omit<Prescription, 'id' | 'created_at'>) => Promise<Prescription | null>;
  addOrder: (order: Omit<Order, 'id' | 'created_at' | 'updated_at'>) => Promise<Order | null>;
  updateOrderStatus: (id: string, status: string) => Promise<void>;
  updateOrder: (id: string, updates: Partial<Order>) => Promise<void>;
}

const ClinicContext = createContext<ClinicContextType | undefined>(undefined);

export function ClinicProvider({ children }: { children: ReactNode }) {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshData = async () => {
    try {
      const [patientsRes, prescriptionsRes, ordersRes] = await Promise.all([
        supabase.from('patients').select('*').order('created_at', { ascending: false }),
        supabase.from('prescriptions').select('*').order('created_at', { ascending: false }),
        supabase.from('orders').select('*').order('created_at', { ascending: false }),
      ]);

      if (patientsRes.data) setPatients(patientsRes.data);
      if (prescriptionsRes.data) setPrescriptions(prescriptionsRes.data);
      if (ordersRes.data) setOrders(ordersRes.data);
    } catch (error) {
      console.error('Error refreshing data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const addPatient = async (patientData: Omit<Patient, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('patients')
        .insert([patientData])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        setPatients(prev => [data, ...prev]);
        toast.success('Patient added successfully');
        return data;
      }
      return null;
    } catch (error) {
      console.error('Error adding patient:', error);
      toast.error('Failed to add patient');
      return null;
    }
  };

  const updatePatient = async (id: string, updates: Partial<Patient>) => {
    try {
      const { error } = await supabase
        .from('patients')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      setPatients(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      toast.success('Patient updated successfully');
    } catch (error) {
      console.error('Error updating patient:', error);
      toast.error('Failed to update patient');
    }
  };

  const deletePatient = async (id: string) => {
    try {
      const { error } = await supabase
        .from('patients')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setPatients(prev => prev.filter(p => p.id !== id));
      setPrescriptions(prev => prev.filter(pr => pr.patient_id !== id));
      setOrders(prev => prev.filter(o => o.patient_id !== id));
      toast.success('Patient deleted successfully');
    } catch (error) {
      console.error('Error deleting patient:', error);
      toast.error('Failed to delete patient');
    }
  };

  const addPrescription = async (prescriptionData: Omit<Prescription, 'id' | 'created_at'>) => {
    try {
      const { data, error } = await supabase
        .from('prescriptions')
        .insert([prescriptionData])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        setPrescriptions(prev => [data, ...prev]);
        toast.success('Prescription added successfully');
        return data;
      }
      return null;
    } catch (error) {
      console.error('Error adding prescription:', error);
      toast.error('Failed to add prescription');
      return null;
    }
  };

  const addOrder = async (orderData: Omit<Order, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        setOrders(prev => [data, ...prev]);
        toast.success('Order created successfully');
        return data;
      }
      return null;
    } catch (error) {
      console.error('Error adding order:', error);
      toast.error('Failed to create order');
      return null;
    }
  };

  const updateOrderStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
      toast.success('Order status updated');
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Failed to update order status');
    }
  };

  const updateOrder = async (id: string, updates: Partial<Order>) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
      toast.success('Order updated successfully');
    } catch (error) {
      console.error('Error updating order:', error);
      toast.error('Failed to update order');
    }
  };

  return (
    <ClinicContext.Provider
      value={{
        patients,
        prescriptions,
        orders,
        loading,
        refreshData,
        addPatient,
        updatePatient,
        deletePatient,
        addPrescription,
        addOrder,
        updateOrderStatus,
        updateOrder,
      }}
    >
      {children}
    </ClinicContext.Provider>
  );
}

export function useClinic() {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within a ClinicProvider');
  }
  return context;
}

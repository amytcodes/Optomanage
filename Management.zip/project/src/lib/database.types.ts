export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      patients: {
        Row: {
          id: string
          name: string
          phone: string
          dob: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          phone: string
          dob?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          phone?: string
          dob?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      prescriptions: {
        Row: {
          id: string
          patient_id: string
          od_sph: number | null
          od_cyl: number | null
          od_axis: number | null
          od_add: number | null
          os_sph: number | null
          os_cyl: number | null
          os_axis: number | null
          os_add: number | null
          pd: number | null
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          patient_id: string
          od_sph?: number | null
          od_cyl?: number | null
          od_axis?: number | null
          od_add?: number | null
          os_sph?: number | null
          os_cyl?: number | null
          os_axis?: number | null
          os_add?: number | null
          pd?: number | null
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          patient_id?: string
          od_sph?: number | null
          od_cyl?: number | null
          od_axis?: number | null
          od_add?: number | null
          os_sph?: number | null
          os_cyl?: number | null
          os_axis?: number | null
          os_add?: number | null
          pd?: number | null
          notes?: string | null
          created_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          patient_id: string
          prescription_id: string | null
          frame_type: string | null
          frame_brand: string | null
          lens_type: string | null
          lens_coating: string | null
          status: string
          amount: number
          advance_paid: number
          balance: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          patient_id: string
          prescription_id?: string | null
          frame_type?: string | null
          frame_brand?: string | null
          lens_type?: string | null
          lens_coating?: string | null
          status?: string
          amount?: number
          advance_paid?: number
          balance?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          patient_id?: string
          prescription_id?: string | null
          frame_type?: string | null
          frame_brand?: string | null
          lens_type?: string | null
          lens_coating?: string | null
          status?: string
          amount?: number
          advance_paid?: number
          balance?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}

export type Patient = Database['public']['Tables']['patients']['Row'];
export type Prescription = Database['public']['Tables']['prescriptions']['Row'];
export type Order = Database['public']['Tables']['orders']['Row'];

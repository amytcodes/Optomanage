import { useNavigate } from 'react-router-dom';
import { useClinic } from '../context/ClinicContext';
import { Users, Package, CheckCircle, Calendar } from 'lucide-react';

export function Dashboard() {
  const navigate = useNavigate();
  const { patients, orders, loading } = useClinic();

  const readyOrders = orders.filter(o => o.status === 'ready');
  const followUps = orders.filter(o => o.status === 'delivered');

  const stats = [
    {
      title: 'Total Patients',
      value: patients.length,
      icon: Users,
      color: 'bg-blue-500',
      onClick: () => navigate('/patients'),
    },
    {
      title: 'Total Orders',
      value: orders.length,
      icon: Package,
      color: 'bg-green-500',
      onClick: () => navigate('/orders'),
    },
    {
      title: 'Ready for Pickup',
      value: readyOrders.length,
      icon: CheckCircle,
      color: 'bg-orange-500',
      onClick: () => navigate('/orders?status=ready'),
    },
    {
      title: 'Follow-ups',
      value: followUps.length,
      icon: Calendar,
      color: 'bg-purple-500',
      onClick: () => navigate('/follow-ups'),
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <button
            key={stat.title}
            onClick={stat.onClick}
            className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer text-left group"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
              </div>
              <div className={`${stat.color} rounded-lg p-3 group-hover:scale-110 transition-transform`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Orders</h3>
          {orders.slice(0, 5).length === 0 ? (
            <p className="text-gray-500 text-center py-4">No orders yet</p>
          ) : (
            <div className="space-y-3">
              {orders.slice(0, 5).map(order => {
                const patient = patients.find(p => p.id === order.patient_id);
                return (
                  <div key={order.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                    <div>
                      <p className="font-medium text-gray-900">{patient?.name || 'Unknown'}</p>
                      <p className="text-sm text-gray-500 capitalize">{order.status.replace('_', ' ')}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">₹{order.amount}</p>
                      <p className="text-sm text-gray-500">Bal: ₹{order.balance}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Patients</h3>
          {patients.slice(0, 5).length === 0 ? (
            <p className="text-gray-500 text-center py-4">No patients yet</p>
          ) : (
            <div className="space-y-3">
              {patients.slice(0, 5).map(patient => (
                <div key={patient.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                  <div>
                    <p className="font-medium text-gray-900">{patient.name}</p>
                    <p className="text-sm text-gray-500">{patient.phone}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

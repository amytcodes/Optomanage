import { useClinic } from '../context/ClinicContext';
import { Calendar, Phone } from 'lucide-react';
import { format, addDays } from 'date-fns';

export function FollowUps() {
  const { orders, patients, loading } = useClinic();

  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  const followUpOrders = deliveredOrders.map(order => {
    const patient = patients.find(p => p.id === order.patient_id);
    const deliveryDate = new Date(order.updated_at);
    const followUpDate = addDays(deliveryDate, 7);
    const isDue = new Date() >= followUpDate;

    return {
      ...order,
      patient,
      followUpDate,
      isDue,
    };
  }).sort((a, b) => a.followUpDate.getTime() - b.followUpDate.getTime());

  const dueFollowUps = followUpOrders.filter(f => f.isDue);
  const upcomingFollowUps = followUpOrders.filter(f => !f.isDue);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Follow-ups</h2>

      {followUpOrders.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <p className="text-gray-500">No follow-ups scheduled</p>
        </div>
      ) : (
        <div className="space-y-6">
          {dueFollowUps.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Due Now</h3>
              <div className="grid gap-4">
                {dueFollowUps.map(item => (
                  <div key={item.id} className="bg-white rounded-lg shadow-sm border-l-4 border-red-500 p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900">{item.patient?.name}</h4>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {item.patient?.phone}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            Due: {format(item.followUpDate, 'dd/MM/yyyy')}
                          </div>
                        </div>
                        <p className="text-sm text-gray-500 mt-2">
                          Delivered on {format(new Date(item.updated_at), 'dd/MM/yyyy')}
                        </p>
                      </div>
                      <a
                        href={`tel:${item.patient?.phone}`}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                      >
                        Call Now
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {upcomingFollowUps.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Upcoming</h3>
              <div className="grid gap-4">
                {upcomingFollowUps.map(item => (
                  <div key={item.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900">{item.patient?.name}</h4>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {item.patient?.phone}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            Follow-up: {format(item.followUpDate, 'dd/MM/yyyy')}
                          </div>
                        </div>
                        <p className="text-sm text-gray-500 mt-2">
                          Delivered on {format(new Date(item.updated_at), 'dd/MM/yyyy')}
                        </p>
                      </div>
                      <a
                        href={`tel:${item.patient?.phone}`}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                      >
                        Call
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

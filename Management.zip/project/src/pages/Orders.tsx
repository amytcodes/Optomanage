import { useState, useCallback, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useClinic } from '../context/ClinicContext';
import { Plus, X } from 'lucide-react';
import { format } from 'date-fns';

const STATUS_OPTIONS = [
  { value: 'eye_tested', label: 'Eye Tested' },
  { value: 'ordered', label: 'Ordered' },
  { value: 'in_lab', label: 'In Lab' },
  { value: 'ready', label: 'Ready' },
  { value: 'delivered', label: 'Delivered' },
];

export function Orders() {
  const { orders, patients, prescriptions, loading, addOrder, updateOrderStatus, updateOrder } = useClinic();
  const [searchParams] = useSearchParams();
  const statusFilter = searchParams.get('status');

  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [selectedPrescriptionId, setSelectedPrescriptionId] = useState('');

  const [formData, setFormData] = useState({
    frame_type: '',
    frame_brand: '',
    lens_type: '',
    lens_coating: '',
    amount: '',
    advance_paid: '',
  });

  const handleInputChange = useCallback((field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId) return;

    const amount = parseFloat(formData.amount) || 0;
    const advancePaid = parseFloat(formData.advance_paid) || 0;
    const balance = amount - advancePaid;

    await addOrder({
      patient_id: selectedPatientId,
      prescription_id: selectedPrescriptionId || null,
      frame_type: formData.frame_type || null,
      frame_brand: formData.frame_brand || null,
      lens_type: formData.lens_type || null,
      lens_coating: formData.lens_coating || null,
      status: 'eye_tested',
      amount,
      advance_paid: advancePaid,
      balance,
    });

    setFormData({
      frame_type: '',
      frame_brand: '',
      lens_type: '',
      lens_coating: '',
      amount: '',
      advance_paid: '',
    });
    setSelectedPatientId('');
    setSelectedPrescriptionId('');
    setShowAddForm(false);
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    await updateOrderStatus(orderId, newStatus);
  };

  const handlePaymentUpdate = async (orderId: string, advancePaid: number) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    const balance = order.amount - advancePaid;
    await updateOrder(orderId, { advance_paid: advancePaid, balance });
  };

  const patientPrescriptions = selectedPatientId
    ? prescriptions.filter(p => p.patient_id === selectedPatientId)
    : [];

  const filteredOrders = statusFilter
    ? orders.filter(o => o.status === statusFilter)
    : orders;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'eye_tested': return 'bg-gray-100 text-gray-800';
      case 'ordered': return 'bg-blue-100 text-blue-800';
      case 'in_lab': return 'bg-yellow-100 text-yellow-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Orders</h2>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Order
        </button>
      </div>

      {statusFilter && (
        <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">
            Filtered by status: <span className="font-medium capitalize">{statusFilter.replace('_', ' ')}</span>
          </p>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Loading...</div>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <p className="text-gray-500">No orders found</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {filteredOrders.map(order => {
            const patient = patients.find(p => p.id === order.patient_id);
            return (
              <div key={order.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{patient?.name || 'Unknown Patient'}</h3>
                    <p className="text-sm text-gray-500">{patient?.phone}</p>
                    <p className="text-sm text-gray-500">{format(new Date(order.created_at), 'dd/MM/yyyy')}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)} border-0 cursor-pointer`}
                    >
                      {STATUS_OPTIONS.map(option => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-500">Frame Type</p>
                    <p className="font-medium text-gray-900">{order.frame_type || '-'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Frame Brand</p>
                    <p className="font-medium text-gray-900">{order.frame_brand || '-'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Lens Type</p>
                    <p className="font-medium text-gray-900">{order.lens_type || '-'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Lens Coating</p>
                    <p className="font-medium text-gray-900">{order.lens_coating || '-'}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
                  <div>
                    <p className="text-xs text-gray-500">Total Amount</p>
                    <p className="text-lg font-bold text-gray-900">₹{order.amount}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Advance Paid</p>
                    <p className="text-lg font-bold text-green-600">₹{order.advance_paid}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Balance</p>
                    <p className="text-lg font-bold text-red-600">₹{order.balance}</p>
                  </div>
                </div>

                {order.balance > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex gap-2">
                      <input
                        type="number"
                        placeholder="Add payment amount"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            const input = e.currentTarget;
                            const amount = parseFloat(input.value);
                            if (amount > 0) {
                              const newAdvance = order.advance_paid + amount;
                              handlePaymentUpdate(order.id, newAdvance);
                              input.value = '';
                            }
                          }
                        }}
                      />
                      <button
                        onClick={(e) => {
                          const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                          const amount = parseFloat(input.value);
                          if (amount > 0) {
                            const newAdvance = order.advance_paid + amount;
                            handlePaymentUpdate(order.id, newAdvance);
                            input.value = '';
                          }
                        }}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                      >
                        Add Payment
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6 my-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Add New Order</h3>
              <button onClick={() => setShowAddForm(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Patient *</label>
                  <select
                    value={selectedPatientId}
                    onChange={(e) => {
                      setSelectedPatientId(e.target.value);
                      setSelectedPrescriptionId('');
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Choose a patient</option>
                    {patients.map(patient => (
                      <option key={patient.id} value={patient.id}>{patient.name} - {patient.phone}</option>
                    ))}
                  </select>
                </div>

                {patientPrescriptions.length > 0 && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Link Prescription (Optional)</label>
                    <select
                      value={selectedPrescriptionId}
                      onChange={(e) => setSelectedPrescriptionId(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">No prescription</option>
                      {patientPrescriptions.map(prescription => (
                        <option key={prescription.id} value={prescription.id}>
                          Prescription from {format(new Date(prescription.created_at), 'dd/MM/yyyy')}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Frame Type</label>
                    <input
                      type="text"
                      value={formData.frame_type}
                      onChange={(e) => handleInputChange('frame_type', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Frame Brand</label>
                    <input
                      type="text"
                      value={formData.frame_brand}
                      onChange={(e) => handleInputChange('frame_brand', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Lens Type</label>
                    <input
                      type="text"
                      value={formData.lens_type}
                      onChange={(e) => handleInputChange('lens_type', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Lens Coating</label>
                    <input
                      type="text"
                      value={formData.lens_coating}
                      onChange={(e) => handleInputChange('lens_coating', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Total Amount *</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.amount}
                      onChange={(e) => handleInputChange('amount', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Advance Paid</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.advance_paid}
                      onChange={(e) => handleInputChange('advance_paid', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {formData.amount && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600">
                      Balance: <span className="font-medium text-gray-900">
                        ₹{(parseFloat(formData.amount) - (parseFloat(formData.advance_paid) || 0)).toFixed(2)}
                      </span>
                    </p>
                  </div>
                )}
              </div>
              <div className="mt-6 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Create Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

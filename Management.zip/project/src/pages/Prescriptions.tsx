import { useState, useCallback } from 'react';
import { useClinic } from '../context/ClinicContext';
import { Plus, Download, Printer, Share2, X } from 'lucide-react';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';

export function Prescriptions() {
  const { prescriptions, patients, loading, addPrescription } = useClinic();
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [formData, setFormData] = useState({
    od_sph: '',
    od_cyl: '',
    od_axis: '',
    od_add: '',
    os_sph: '',
    os_cyl: '',
    os_axis: '',
    os_add: '',
    pd: '',
    notes: '',
  });

  const handleInputChange = useCallback((field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId) return;

    await addPrescription({
      patient_id: selectedPatientId,
      od_sph: formData.od_sph ? parseFloat(formData.od_sph) : null,
      od_cyl: formData.od_cyl ? parseFloat(formData.od_cyl) : null,
      od_axis: formData.od_axis ? parseFloat(formData.od_axis) : null,
      od_add: formData.od_add ? parseFloat(formData.od_add) : null,
      os_sph: formData.os_sph ? parseFloat(formData.os_sph) : null,
      os_cyl: formData.os_cyl ? parseFloat(formData.os_cyl) : null,
      os_axis: formData.os_axis ? parseFloat(formData.os_axis) : null,
      os_add: formData.os_add ? parseFloat(formData.os_add) : null,
      pd: formData.pd ? parseFloat(formData.pd) : null,
      notes: formData.notes || null,
    });

    setFormData({
      od_sph: '',
      od_cyl: '',
      od_axis: '',
      od_add: '',
      os_sph: '',
      os_cyl: '',
      os_axis: '',
      os_add: '',
      pd: '',
      notes: '',
    });
    setSelectedPatientId('');
    setShowAddForm(false);
  };

  const generatePDF = (prescriptionId: string) => {
    const prescription = prescriptions.find(p => p.id === prescriptionId);
    if (!prescription) return;

    const patient = patients.find(p => p.id === prescription.patient_id);
    if (!patient) return;

    const doc = new jsPDF();

    doc.setFontSize(20);
    doc.text('PRESCRIPTION', 105, 20, { align: 'center' });

    doc.setFontSize(12);
    doc.text('Optometry Clinic', 105, 30, { align: 'center' });

    doc.setFontSize(10);
    doc.line(20, 35, 190, 35);

    doc.setFontSize(12);
    doc.text(`Patient: ${patient.name}`, 20, 45);
    doc.text(`Phone: ${patient.phone}`, 20, 52);
    doc.text(`Date: ${format(new Date(prescription.created_at), 'dd/MM/yyyy')}`, 20, 59);

    doc.setFontSize(11);
    doc.text('EYE PRESCRIPTION', 20, 75);

    const headers = ['', 'SPH', 'CYL', 'AXIS', 'ADD'];
    const data = [
      ['OD (Right)', prescription.od_sph || '-', prescription.od_cyl || '-', prescription.od_axis || '-', prescription.od_add || '-'],
      ['OS (Left)', prescription.os_sph || '-', prescription.os_cyl || '-', prescription.os_axis || '-', prescription.os_add || '-'],
    ];

    let y = 85;
    const colWidths = [40, 30, 30, 30, 30];
    const startX = 20;

    doc.setFillColor(240, 240, 240);
    doc.rect(startX, y - 5, colWidths.reduce((a, b) => a + b, 0), 8, 'F');

    headers.forEach((header, i) => {
      const x = startX + colWidths.slice(0, i).reduce((a, b) => a + b, 0);
      doc.text(header, x + 2, y);
    });

    y += 10;

    data.forEach(row => {
      row.forEach((cell, i) => {
        const x = startX + colWidths.slice(0, i).reduce((a, b) => a + b, 0);
        doc.text(String(cell), x + 2, y);
      });
      y += 8;
    });

    y += 5;
    doc.text(`PD (Pupillary Distance): ${prescription.pd || '-'}`, 20, y);

    if (prescription.notes) {
      y += 15;
      doc.text('Notes:', 20, y);
      y += 7;
      const splitNotes = doc.splitTextToSize(prescription.notes, 170);
      doc.text(splitNotes, 20, y);
    }

    doc.save(`prescription_${patient.name}_${format(new Date(), 'yyyyMMdd')}.pdf`);
  };

  const printPrescription = (prescriptionId: string) => {
    const prescription = prescriptions.find(p => p.id === prescriptionId);
    if (!prescription) return;

    const patient = patients.find(p => p.id === prescription.patient_id);
    if (!patient) return;

    const printWindow = window.open('', '', 'width=800,height=600');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Prescription - ${patient.name}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 10px; }
            .patient-info { margin-bottom: 30px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #000; padding: 8px; text-align: left; }
            th { background-color: #f0f0f0; }
            .notes { margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>PRESCRIPTION</h1>
            <p>Optometry Clinic</p>
          </div>
          <div class="patient-info">
            <p><strong>Patient:</strong> ${patient.name}</p>
            <p><strong>Phone:</strong> ${patient.phone}</p>
            <p><strong>Date:</strong> ${format(new Date(prescription.created_at), 'dd/MM/yyyy')}</p>
          </div>
          <h3>Eye Prescription</h3>
          <table>
            <tr>
              <th></th>
              <th>SPH</th>
              <th>CYL</th>
              <th>AXIS</th>
              <th>ADD</th>
            </tr>
            <tr>
              <td><strong>OD (Right)</strong></td>
              <td>${prescription.od_sph || '-'}</td>
              <td>${prescription.od_cyl || '-'}</td>
              <td>${prescription.od_axis || '-'}</td>
              <td>${prescription.od_add || '-'}</td>
            </tr>
            <tr>
              <td><strong>OS (Left)</strong></td>
              <td>${prescription.os_sph || '-'}</td>
              <td>${prescription.os_cyl || '-'}</td>
              <td>${prescription.os_axis || '-'}</td>
              <td>${prescription.os_add || '-'}</td>
            </tr>
          </table>
          <p><strong>PD (Pupillary Distance):</strong> ${prescription.pd || '-'}</p>
          ${prescription.notes ? `<div class="notes"><h4>Notes:</h4><p>${prescription.notes}</p></div>` : ''}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  const shareWhatsApp = (prescriptionId: string) => {
    const prescription = prescriptions.find(p => p.id === prescriptionId);
    if (!prescription) return;

    const patient = patients.find(p => p.id === prescription.patient_id);
    if (!patient) return;

    const message = `*PRESCRIPTION*

*Patient:* ${patient.name}
*Date:* ${format(new Date(prescription.created_at), 'dd/MM/yyyy')}

*Eye Prescription:*
*OD (Right Eye):*
SPH: ${prescription.od_sph || '-'} | CYL: ${prescription.od_cyl || '-'} | AXIS: ${prescription.od_axis || '-'} | ADD: ${prescription.od_add || '-'}

*OS (Left Eye):*
SPH: ${prescription.os_sph || '-'} | CYL: ${prescription.os_cyl || '-'} | AXIS: ${prescription.os_axis || '-'} | ADD: ${prescription.os_add || '-'}

*PD:* ${prescription.pd || '-'}
${prescription.notes ? `\n*Notes:* ${prescription.notes}` : ''}`;

    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Prescriptions</h2>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Prescription
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Loading...</div>
        </div>
      ) : prescriptions.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <p className="text-gray-500">No prescriptions yet</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {prescriptions.map(prescription => {
            const patient = patients.find(p => p.id === prescription.patient_id);
            return (
              <div key={prescription.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{patient?.name || 'Unknown Patient'}</h3>
                    <p className="text-sm text-gray-500">{format(new Date(prescription.created_at), 'dd/MM/yyyy')}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => generatePDF(prescription.id)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Download PDF"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => printPrescription(prescription.id)}
                      className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                      title="Print"
                    >
                      <Printer className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => shareWhatsApp(prescription.id)}
                      className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                      title="Share on WhatsApp"
                    >
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">OD (Right Eye)</h4>
                    <div className="space-y-1 text-sm">
                      <p><span className="text-gray-500">SPH:</span> <span className="font-medium">{prescription.od_sph || '-'}</span></p>
                      <p><span className="text-gray-500">CYL:</span> <span className="font-medium">{prescription.od_cyl || '-'}</span></p>
                      <p><span className="text-gray-500">AXIS:</span> <span className="font-medium">{prescription.od_axis || '-'}</span></p>
                      <p><span className="text-gray-500">ADD:</span> <span className="font-medium">{prescription.od_add || '-'}</span></p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">OS (Left Eye)</h4>
                    <div className="space-y-1 text-sm">
                      <p><span className="text-gray-500">SPH:</span> <span className="font-medium">{prescription.os_sph || '-'}</span></p>
                      <p><span className="text-gray-500">CYL:</span> <span className="font-medium">{prescription.os_cyl || '-'}</span></p>
                      <p><span className="text-gray-500">AXIS:</span> <span className="font-medium">{prescription.os_axis || '-'}</span></p>
                      <p><span className="text-gray-500">ADD:</span> <span className="font-medium">{prescription.os_add || '-'}</span></p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-sm"><span className="text-gray-500">PD:</span> <span className="font-medium">{prescription.pd || '-'}</span></p>
                  {prescription.notes && (
                    <p className="text-sm mt-2"><span className="text-gray-500">Notes:</span> <span className="font-medium">{prescription.notes}</span></p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full p-6 my-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Add New Prescription</h3>
              <button onClick={() => setShowAddForm(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Patient *</label>
                  <select
                    value={selectedPatientId}
                    onChange={(e) => setSelectedPatientId(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Choose a patient</option>
                    {patients.map(patient => (
                      <option key={patient.id} value={patient.id}>{patient.name} - {patient.phone}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-2">OD (Right Eye)</h4>
                  <div className="grid grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">SPH</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.od_sph}
                        onChange={(e) => handleInputChange('od_sph', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">CYL</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.od_cyl}
                        onChange={(e) => handleInputChange('od_cyl', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">AXIS</label>
                      <input
                        type="number"
                        step="1"
                        min="0"
                        max="180"
                        value={formData.od_axis}
                        onChange={(e) => handleInputChange('od_axis', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">ADD</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.od_add}
                        onChange={(e) => handleInputChange('od_add', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-2">OS (Left Eye)</h4>
                  <div className="grid grid-cols-4 gap-3">
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">SPH</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.os_sph}
                        onChange={(e) => handleInputChange('os_sph', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">CYL</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.os_cyl}
                        onChange={(e) => handleInputChange('os_cyl', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">AXIS</label>
                      <input
                        type="number"
                        step="1"
                        min="0"
                        max="180"
                        value={formData.os_axis}
                        onChange={(e) => handleInputChange('os_axis', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-600 mb-1">ADD</label>
                      <input
                        type="number"
                        step="0.25"
                        value={formData.os_add}
                        onChange={(e) => handleInputChange('os_add', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">PD (Pupillary Distance)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formData.pd}
                    onChange={(e) => handleInputChange('pd', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add Prescription
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

/*
  # Optometry Clinic Management System Schema

  1. New Tables
    - patients: Store patient information
    - prescriptions: Store eye prescription details
    - orders: Store order and billing information

  2. Security
    - Enable RLS on all tables
    - Add policies for public access (simplified for clinic use)
*/

-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  dob date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create prescriptions table
CREATE TABLE IF NOT EXISTS prescriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  od_sph numeric,
  od_cyl numeric,
  od_axis numeric,
  od_add numeric,
  os_sph numeric,
  os_cyl numeric,
  os_axis numeric,
  os_add numeric,
  pd numeric,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  prescription_id uuid REFERENCES prescriptions(id) ON DELETE SET NULL,
  frame_type text,
  frame_brand text,
  lens_type text,
  lens_coating text,
  status text DEFAULT 'eye_tested',
  amount numeric DEFAULT 0,
  advance_paid numeric DEFAULT 0,
  balance numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (for clinic use)
CREATE POLICY "Allow all operations on patients"
  ON patients FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on prescriptions"
  ON prescriptions FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on orders"
  ON orders FOR ALL
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_orders_patient_id ON orders(patient_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

import { useNavigate } from "react-router-dom";

export default function Dashboard(){
  const nav = useNavigate();

  return(
    <div style={{padding:20}}>
      <h1>Clinic Dashboard</h1>
      <div style={{display:"flex",gap:10}}>
        <button onClick={()=>nav('/patients')}>Patients</button>
        <button onClick={()=>nav('/prescriptions')}>Prescriptions</button>
        <button onClick={()=>nav('/orders')}>Orders</button>
      </div>
    </div>
  )
}

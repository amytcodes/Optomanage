
import { useStore } from "../store";

export default function Orders(){
  const {orders,addOrder,updateOrderStatus} = useStore();

  return(
    <div style={{padding:20}}>
      <h2>Orders</h2>

      <button onClick={()=>addOrder({frame:"Generic",lens:"Bluecut"})}>
        Add Order
      </button>

      {orders.map(o=>(
        <div key={o.id}>
          {o.frame} | {o.status}
          <button onClick={()=>updateOrderStatus(o.id,"In Lab")}>Lab</button>
          <button onClick={()=>updateOrderStatus(o.id,"Ready")}>Ready</button>
          <button onClick={()=>updateOrderStatus(o.id,"Delivered")}>Delivered</button>
        </div>
      ))}
    </div>
  )
}

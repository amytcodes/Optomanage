
import { useState } from "react";
import { useStore } from "../store";

export default function Patients(){
  const {patients,addPatient} = useStore();
  const [form,setForm]=useState({name:"",phone:""});

  return(
    <div style={{padding:20}}>
      <h2>Patients</h2>

      <input placeholder="Name" value={form.name}
        onChange={e=>setForm({...form,name:e.target.value})}/>

      <input placeholder="Phone" value={form.phone}
        onChange={e=>setForm({...form,phone:e.target.value})}/>

      <button onClick={()=>{addPatient(form);setForm({name:"",phone:""})}}>
        Save
      </button>

      {patients.map(p=>(
        <div key={p.id}>{p.name} - {p.phone}</div>
      ))}
    </div>
  )
}

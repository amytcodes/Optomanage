
import { useState } from "react";
import { useStore } from "../store";
import jsPDF from "jspdf";

export default function Prescriptions(){
  const {patients,addPrescription,prescriptions} = useStore();
  const [form,setForm]=useState({patientId:"",od:"",os:"",pd:""});

  const createPDF=(p)=>{
    const doc=new jsPDF();
    doc.text("Prescription",20,20);
    doc.text(`OD: ${p.od}`,20,40);
    doc.text(`OS: ${p.os}`,20,50);
    doc.save("prescription.pdf");
  }

  return(
    <div style={{padding:20}}>
      <h2>Prescriptions</h2>

      <select onChange={e=>setForm({...form,patientId:e.target.value})}>
        <option>Select Patient</option>
        {patients.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
      </select>

      <input placeholder="OD" onChange={e=>setForm({...form,od:e.target.value})}/>
      <input placeholder="OS" onChange={e=>setForm({...form,os:e.target.value})}/>
      <input placeholder="PD" onChange={e=>setForm({...form,pd:e.target.value})}/>

      <button onClick={()=>addPrescription(form)}>Save Rx</button>

      {prescriptions.map(p=>(
        <div key={p.id}>
          {p.od}/{p.os}
          <button onClick={()=>createPDF(p)}>PDF</button>
          <button onClick={()=>window.print()}>Print</button>
        </div>
      ))}
    </div>
  )
}

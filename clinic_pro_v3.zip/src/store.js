
import { create } from 'zustand';
import { nanoid } from 'nanoid';

export const useStore = create((set)=>({
  patients: [],
  prescriptions: [],
  orders: [],

  addPatient:(data)=>set(s=>({
    patients:[{id:nanoid(),createdAt:Date.now(),...data},...s.patients]
  })),

  addPrescription:(data)=>set(s=>({
    prescriptions:[{id:nanoid(),createdAt:Date.now(),...data},...s.prescriptions]
  })),

  addOrder:(data)=>set(s=>({
    orders:[{id:nanoid(),status:"Ordered",paymentStatus:"Unpaid",createdAt:Date.now(),...data},...s.orders]
  })),

  updateOrderStatus:(id,status)=>set(s=>({
    orders:s.orders.map(o=>o.id===id?{...o,status}:o)
  }))
}));
